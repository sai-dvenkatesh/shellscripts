a=`pwd`
echo hello today date is "`date`"
echo "hello today date is `date`"
echo $a

