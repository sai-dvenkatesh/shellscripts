echo "enter a number1"
read num1
echo "enter a number2"
read num2
c=`expr $num1 \* $num2`
echo "result is $c"
