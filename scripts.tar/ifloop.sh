echo "enter your age"
read age
if [ $age -ge 18 ]
		then
	echo "u r elgible to vote"
		else
echo "u r not elgible to vote"
	fi
