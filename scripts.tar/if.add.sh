a=
b= 
c=`expr $a + $b`
echo $c
