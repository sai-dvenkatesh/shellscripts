sqlplus / as sysdba <<EOF
startup force
shutdown immediate
startup mount
alter database open
EOF

