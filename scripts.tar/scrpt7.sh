#!/bin/bash
#Purpose:
#Author:
#last modified:

echo "enter the file name"
read fn
if [ -d $fn ]
then
echo "file exists and it is a directory"
elif [ -c $fn ]
then
echo " file exists and it is a character file"
elif [ -f $fn ]
then 
echo " file exists and it is regular file"
elif [ -b $fn ]
then
echo " file exits and it is block device file"
else
echo " file not exists"
fi

