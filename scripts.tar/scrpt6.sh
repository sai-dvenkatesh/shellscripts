#! /bin/bash
#Purpose:
#Author:
#Date:
#last modified:
cd ~
clear
echo "enter a file name"
read fn
if [ -a $fn ]
then
echo "file exits"
if [ -d $fn ]
then 
echo "file is directory"
else
echo "file is not a directory"
fi
	else
echo "file is not exits"
fi
#END

