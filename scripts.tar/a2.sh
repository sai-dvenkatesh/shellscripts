echo "enter a 1st value"
read a
echo "enter a 2nd value"
read b
c=`expr $a \* $b` 
echo "the result is $c"
klsdfjlas
