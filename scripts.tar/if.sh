echo "enter the age"
read age
if [ $age -ge 18 ]
	then
echo "elgible to vote"
	else
echo "not elgible"
	fi
