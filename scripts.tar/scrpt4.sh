#!/bin/bash
#script Name:
#Author:
#Purpose:
#Date:
#Modified:

echo "today date is `date`"
echo "these are the process running"
ps -l
echo "who are the users logged in"
who
 
