B=50
echo "$B is the given variable value"
echo "enter your vairable value"
read C
echo "$C is value of the variable you have given"
echo -e "good morning\n welcome to shellscipt"
read -s -p "enter any name" name
echo -n "the name is $name"

