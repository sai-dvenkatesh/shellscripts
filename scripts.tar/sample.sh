sqlplus / as sysdba
startup force
select * from exp;
