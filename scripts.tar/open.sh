add ()
	{
	c=`expr $a + $b`
	}
	sub ()
	{
	c=`expr $a - $b`
	}

