threshold=20
a=`df -h /usr | awk -F " " '{print $5}'| tail -1|cut -c1,2`
if [ $a -eq $threshold ]
	then
mail -s "disk space" root <<EOF
echo "usage value is $a"
EOF
 	else
mail -s "disk space" root <<EOF
       echo "usage ok"
EOF
fi

	
