echo "enter value1"
read val1
echo "enter value2"
read val2
val3=`expr $val1 \* $val2`
echo "The result is $val3"
