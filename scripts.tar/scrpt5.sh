#!/bin/bash
#Purpose:
#Author:
#Date:
#Last modified Date:
cd ~
clear
echo "enter a filename"
read fn
if test -a $fn
then
echo "file exists"
else
echo "file not exists"
fi
#END
