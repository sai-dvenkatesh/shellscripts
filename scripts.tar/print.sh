echo "enter your name"
read name
echo "your name is $name"
