sdfasjdfjwhile [ $i -le 10 ]
	do
	echo $i
       ((i++))
	done
