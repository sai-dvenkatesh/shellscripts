echo "enter your age"
read age
if [ $age -ge 18 ]
	then
	echo "you're elgible to vote"
	else
echo "your not elgible"
fi
